close all;
clear all;
clc;
C = 604.1*10^-6; % capacitance [Farads]
V = 540; % bus voltage 
R = 1000; % precharge resistor
fprintf('\n Actual Resistor: %i ohms', R);
i=V/R;
precharge_time=3*R*C;
fprintf('\n Actual Precharge Time: %g seconds', precharge_time);
% time to discharge to 60V
% make sure less than 5 seconds as per EV5.1.3
discharge_time = R * C * log(V/60);
fprintf('\n Discharge time to drop below 60V: %g seconds', discharge_time);
% actual energy dissipated over the precharging event
E = (1/2) *C * V^2;
power = E / precharge_time;
fprintf('\n Power dissipated during precharging event: %g watts', ceil(power));
% maximum power dissipated by resistor
max_power = V^2 / R;
fprintf('\n Peak Power: %g watts', ceil(max_power));